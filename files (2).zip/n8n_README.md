# n8n Workflow — WhatsApp Ad Delivery ✅

## Workflow
```
Manual Trigger → POST /api/generate-ad → Send WhatsApp message
```

## Nodes
1. **Manual Trigger** — starts the workflow on button click
2. **HTTP Request** — calls Jash's AI endpoint
   - URL: `https://trendr-ai-1.onrender.com/api/generate-ad`
   - Method: POST
   - Params: `business_name`, `trend_id`
3. **Twilio** — sends AI headline to WhatsApp
   - From: `whatsapp:+14155238886` (sandbox)
   - Message: `{{ $json.headline }}`

## How to Import
1. Open n8n at `http://localhost:5678`
2. Click "New Workflow" → "..." → "Import from file"
3. Select `My_workflow.json`
4. Add your Twilio credentials
5. Click Execute Workflow ✅

## Test Result
WhatsApp message received with AI-generated ad headline ✅
